---
name: labMU Atelier & Prototyping System
colors:
  surface: '#fef8f7'
  surface-dim: '#ded9d8'
  surface-bright: '#fef8f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f2f2'
  surface-container: '#f3ecec'
  surface-container-high: '#ede7e6'
  surface-container-highest: '#e7e1e1'
  on-surface: '#1d1b1b'
  on-surface-variant: '#584142'
  inverse-surface: '#323030'
  inverse-on-surface: '#f6efef'
  outline: '#8b7171'
  outline-variant: '#dfbfbf'
  surface-tint: '#ad2f40'
  primary: '#670018'
  on-primary: '#ffffff'
  primary-container: '#8b142a'
  on-primary-container: '#ff979c'
  inverse-primary: '#ffb3b5'
  secondary: '#855400'
  on-secondary: '#ffffff'
  secondary-container: '#ffad3a'
  on-secondary-container: '#6d4400'
  tertiary: '#342f2f'
  on-tertiary: '#ffffff'
  tertiary-container: '#4a4545'
  on-tertiary-container: '#bbb2b2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdada'
  primary-fixed-dim: '#ffb3b5'
  on-primary-fixed: '#40000c'
  on-primary-fixed-variant: '#8c152a'
  secondary-fixed: '#ffddb7'
  secondary-fixed-dim: '#ffb95d'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#eae0e0'
  tertiary-fixed-dim: '#cdc4c4'
  on-tertiary-fixed: '#1f1b1b'
  on-tertiary-fixed-variant: '#4b4545'
  background: '#fef8f7'
  on-background: '#1d1b1b'
  surface-variant: '#e7e1e1'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
  stat-display:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 1.75rem
  space-xl: 2.5rem
---

## Brand & Style

This design system is crafted for the museum architecture prototyping laboratory (labMU at MUSARQ - UNICAP). It marries academic rigour and fabrication precision with an artistic, archival architectural atelier atmosphere.

The design movement balances warm architectural minimalism with tactile clarity:
- **Atmosphere:** Clean, open, calm, and deliberate. Surfaces invoke premium textured unbleached paper, architectural model board, and refined workshop materials.
- **Audience:** Lab coordinators, architectural researchers, student operators, and fabrication technicians running digital fabrication equipment (3D printers, laser cutters, CNC routers, woodworking benches).
- **Emotional Response:** Inspires focus, tactile mastery, and spatial clarity. Eliminates technical clutter while presenting high-legibility machinery metrics and status cues.
- **Foundational Rule:** Complete rejection of synthetic digital safety conventions (strict avoidance of green). Trust, confirmation, readiness, and active operations are communicated via rich crimson accents, luminous amber, grounded charcoal ink, and clear typographic and iconography badges.

## Colors

The palette is rooted in natural architectural studio substrates, deep university heritage crimson, and warm metallic accents.

### Color Tokens & Assignments
- **Canvas & Surfaces:**
  - Base canvas: `#FBF9F5` (Alabaster cream / archival vellum)
  - Surface containers / Cards: `#F4EFEB` (Milled plaster / soft paperboard)
  - Elevated surfaces & Input wells: `#ECE5DD` (Compressed warm pulp)
  - Border outlines & Dividers: `#E2D9CE` (Muted line weight)
- **Primary Wine / Deep Crimson:**
  - Base Primary: `#8B142A` (Rich warm wine)
  - Primary Hover / Interactive: `#A61935` (Luminous ruby crimson)
  - Primary Deep / Pressed: `#6E0F20` (Burnt oxblood)
  - Subdued Crimson Tint (Badges / Highlighting): `#F6E6E8`
- **Secondary Amber / Mustard:**
  - Base Secondary: `#D98E18` (Golden mustard / architectural brass)
  - Secondary Light: `#E59F24` (Warm amber)
  - Subdued Amber Wash: `#FAF0DE`
- **Charcoal Typography & Technical Contrast:**
  - Primary Text / High-Contrast Ink: `#1C1A1A` (Grounded charcoal)
  - Secondary Text / Metric Captions: `#3A3535` (Muted graphite)
  - Tertiary / Structural Placeholders: `#5C5555` (Slate stone)

### State Conventions (Strict Negative Constraint: Zero Green)
- **Success / Completed / Ready:** Deep charcoal `#1C1A1A` or crimson `#8B142A` pill badge paired with solid check marks, or warm neutral `#ECE5DD` filled badges with high-contrast text. Never use green.
- **Active / Running / In-Progress:** Warm amber `#D98E18` with pulsing dot indicator or crimson `#8B142A` high-contrast badge.
- **Attention / Alert:** Vibrant warm amber `#E59F24` paired with clear diagnostic iconography.
- **Critical / Error / Emergency Stop:** Deep saturated crimson `#6E0F20` with thick charcoal borders.

## Typography

Typography relies uniformly on **Inter** to ensure maximum legibility across complex fabrication dashboards, machinery queues, and ambient tablet displays.

### Typographic Hierarchy & Character
- **Displays & Headlines:** Set in medium and semi-bold weights with negative tracking (`-0.02em` to `-0.04em`). They communicate quiet authority and structural clarity without screaming.
- **Telemetry & Metric Counters:** Utilize `stat-display` for oversized fabrication progress percentages, temperature readings, and time-remaining values. Numeric figures must use tabular numerals (`tnum`) for layout stability during live data streams.
- **Labels & Microcopy:** Crisp, slightly tracked labels in weights 500 and 600, frequently rendered uppercase in `label-sm` for equipment tags and protocol stages.
- **Editorial Balance:** Wide line heights prevent dense reading fatigue during active fabrication supervision.

## Layout & Spacing

The layout philosophy rejects cramped operational consoles in favour of a spacious, airy architectural studio floor plan. Whitespace functions as structural breathing room.

### Grid & Composition
- **Desktop (1200px+):** 12-column fluid grid, 2rem section margins, 1.5rem gutters. Max content bounding box capped at `1440px` to maintain optimal eye-scanning lines.
- **Tablet / Workshop Kiosk (768px - 1199px):** 8-column grid with 1.5rem gutters. Cards switch from multi-column metrics to double-column overview panels.
- **Mobile (Up to 767px):** 4-column flow with 1rem gutters and 1rem canvas margins.

### Rhythm & Padding Defaults
- Standard card container internal padding defaults to `space-lg` (1.75rem / 28px) or `space-xl` (2.5rem / 40px) for key metrics to prevent visual clutter.
- Vertical layout spacing between dashboard modules uses a 2rem to 3rem cadence.
- Navigation hangs freely as a floating island rather than pinning flush to edge barriers.

## Elevation & Depth

Visual depth is achieved through translucent paperboard layering and soft ambient warm cast shadows, avoiding stark artificial black drop shadows.

### Atmospheric Shadow Values
- **Level 1 (Subtle Card Separation):** `0 2px 10px rgba(28, 26, 26, 0.03), 0 1px 3px rgba(28, 26, 26, 0.02)`
- **Level 2 (Interactive Elements & Hover States):** `0 10px 25px -5px rgba(28, 26, 26, 0.06), 0 4px 10px -2px rgba(28, 26, 26, 0.03)`
- **Level 3 (Floating Pill Navigation & Modals):** `0 20px 40px -10px rgba(28, 26, 26, 0.08), 0 8px 16px -4px rgba(28, 26, 26, 0.04)`

### Glassmorphism & Translucency
- The floating pill navigation bar utilizes `background: rgba(251, 249, 245, 0.82)` coupled with `backdrop-filter: blur(16px)` and an ultra-fine border `1px solid rgba(226, 217, 206, 0.7)`.
- Cards float gently over `#FBF9F5` using `#F4EFEB` with hairline boundaries (`1px solid #E2D9CE`).

## Shapes

The design system embraces generous, sculptured radii reflecting tactile architectural models and milled prototype parts.

### Geometry Hierarchy
- **Floating Island Navigation:** Full pill radius (`rounded-full` / 9999px) creating a contained capsule at the top of the viewport.
- **Panels, Machinery Hubs & Large Cards:** `rounded-2xl` (1rem to 1.25rem / 16px to 20px) ensuring substantial warmth and organic softness.
- **Controls, Action Buttons & Input Wells:** `rounded-xl` (0.75rem / 12px), creating a natural grip target for touch displays and cursor inputs.
- **Chips, Badges & Status Indicators:** Pill shape (`rounded-full`) for instant semantic separation from squarer action items.

## Components

### Floating Navigation Pill
- **Structure:** Centered horizontal floating capsule anchored 1.5rem below the top screen margin. Height 64px, maximum width 960px.
- **Styling:** Frosted cream background (`rgba(251, 249, 245, 0.85)`), hairline perimeter stroke (`#E2D9CE`), Level 3 ambient shadow.
- **Contents:** labMU wordmark in charcoal `#1C1A1A`, center navigation links with subtle wine active indicators, and operator profile or lab status pill badge on the right.

### Buttons
- **Primary Action:** Solid warm wine (`#8B142A`), text `#FBF9F5`, `rounded-xl`, padding `12px 24px`. Hover state transitions to luminous crimson (`#A61935`).
- **Secondary Action:** Cream base (`#F4EFEB`), border `1px solid #E2D9CE`, text `#1C1A1A`. Hover state shifts surface to `#ECE5DD`.
- **Tertiary / Amber Emphasis:** Golden mustard fill (`#D98E18`), text `#FFFFFF`, for non-destructive urgent commands, material queue changes, or calibration triggers.

### Metric Cards & Machine Panels
- **Structure:** Built on `rounded-2xl` containers filled with `#F4EFEB`, bordered with `#E2D9CE`. Internal padding `p-6` or `p-8`.
- **Layout:** Generous separation (`gap-6`) prioritizing the key numerical readout (`stat-display`) followed by secondary parameter breadcrumbs (e.g., "Laser Bed 01 • Acrylic 4mm"). No condensed tabular spreadsheets; each fabrication job is granted visual breathing room.

### Status Chips & Badges (Strict No-Green)
- **Completed / Ready:** Background `#ECE5DD`, text `#1C1A1A`, border `1px solid #E2D9CE`, leading filled circular icon.
- **Active / Milling / Printing:** Background `#FAF0DE`, text `#D98E18`, leading pulsing amber dot.
- **Scheduled / Queued:** Background `#F4EFEB`, text `#5C5555`, subtle grey-charcoal dot.
- **Alert / Warning:** Background `#F6E6E8`, text `#8B142A`, leading triangle or hazard outline icon.

### Form Inputs & Control Fields
- **Container:** `rounded-xl`, background `#ECE5DD`, border `1px solid transparent`, height 48px, text `#1C1A1A`.
- **States:** Focus replaces border with `#8B142A` and applies an ambient wine glow ring `0 0 0 3px rgba(139, 20, 42, 0.12)`.

### Checkboxes & Radios
- **Geometry:** Checkbox `rounded-md` (6px); Radio full circle.
- **Styling:** Border 1.5px `#5C5555` on `#FBF9F5`. Checked state fills with rich wine `#8B142A` and displays crisp cream checkmark or inner pip.

### Lab-Specific Components
- **Spool & Material Gauge:** Horizontal rounded track (`#ECE5DD`, height 8px) with amber `#D98E18` or crimson `#8B142A` progress fill indicating resin/filament level without any green coloration.
- **Emergency / Pause Protocol Strip:** Architectural hatched warm amber and charcoal banner positioned dynamically inside job cards.